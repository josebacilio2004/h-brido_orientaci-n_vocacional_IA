

<?php $__env->startSection('title', 'Pregunta ' . $questionNumber . ' - ' . $test->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
        <div class="max-w-3xl mx-auto">
            
            <div class="mb-6">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-gray-300 text-sm font-medium">Pregunta <?php echo e($questionNumber); ?> de
                        <?php echo e($test->total_questions); ?></span>
                    <span class="text-gray-300 text-sm font-medium"><?php echo e(number_format($progress, 0)); ?>% completado</span>
                </div>
                <div class="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                    <div class="bg-gradient-to-r from-purple-600 to-pink-600 h-full rounded-full transition-all duration-500"
                        style="width: <?php echo e($progress); ?>%"></div>
                </div>
            </div>

            
            <div class="bg-white/10 backdrop-blur-lg rounded-xl p-8 border border-white/20 mb-6">
                <div class="flex items-start gap-4 mb-6">
                    <div
                        class="bg-gradient-to-br from-purple-600 to-pink-600 text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg flex-shrink-0">
                        <?php echo e($questionNumber); ?>

                    </div>
                    <div class="flex-1">
                        <h2 class="text-2xl font-bold text-white mb-2"><?php echo e($question->question); ?></h2>
                        <p class="text-gray-400 text-sm">Selecciona tu nivel de acuerdo con esta afirmación</p>
                    </div>
                </div>

                
                <form action="<?php echo e(route('tests.save-answer', ['id' => $test->id, 'question' => $questionNumber])); ?>"
                    method="POST" id="answerForm">
                    <?php echo csrf_field(); ?>

                    <?php if($question->type === 'scale'): ?>
                        
                        <div class="space-y-4">
                            <div class="flex justify-between text-sm text-gray-400 px-2">
                                <span>Nada de acuerdo</span>
                                <span>Muy de acuerdo</span>
                            </div>
                            <div class="grid grid-cols-5 gap-3">
                                <?php
                                    $labels = ['Nada', 'Poco', 'Neutral', 'De acuerdo', 'Muy de acuerdo'];
                                ?>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <label class="cursor-pointer group block">
                                        <input type="radio" name="answer" value="<?php echo e($i); ?>" class="peer hidden"
                                            <?php echo e($previousAnswer && (int) $previousAnswer->answer === $i ? 'checked' : ''); ?>

                                            required>
                                        <div
                                            class="bg-white/5 border-2 border-gray-500 rounded-xl p-6 text-center 
                                                    transition-all duration-300 transform hover:scale-105
                                                    peer-checked:border-purple-500 peer-checked:bg-purple-600/30 
                                                    peer-checked:scale-110 peer-checked:shadow-lg">
                                            <div
                                                class="text-3xl font-bold text-gray-400 peer-checked:text-purple-200 mb-2 transition-colors duration-300">
                                                <?php echo e($i); ?>

                                            </div>
                                            <div
                                                class="text-xs text-gray-500 peer-checked:text-purple-100 transition-colors duration-300">
                                                <?php echo e($labels[$i - 1]); ?>

                                            </div>
                                        </div>
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    <?php elseif($question->type === 'yes_no'): ?>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <label class="cursor-pointer">
                                <input type="radio" name="answer" value="yes" class="peer sr-only"
                                    <?php echo e($previousAnswer && $previousAnswer->answer == 'yes' ? 'checked' : ''); ?> required>
                                <div
                                    class="bg-white/5 border-2 border-gray-500 rounded-xl p-8 text-center transition-all peer-checked:border-green-500 peer-checked:bg-green-500/20 hover:border-green-400">
                                    <svg class="w-12 h-12 text-gray-400 peer-checked:text-green-400 mx-auto mb-3"
                                        fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M5 13l4 4L19 7"></path>
                                    </svg>
                                    <div class="text-xl font-bold text-gray-300 peer-checked:text-green-300">Sí</div>
                                </div>
                            </label>
                            <label class="cursor-pointer">
                                <input type="radio" name="answer" value="no" class="peer sr-only"
                                    <?php echo e($previousAnswer && $previousAnswer->answer == 'no' ? 'checked' : ''); ?> required>
                                <div
                                    class="bg-white/5 border-2 border-gray-500 rounded-xl p-8 text-center transition-all peer-checked:border-red-500 peer-checked:bg-red-500/20 hover:border-red-400">
                                    <svg class="w-12 h-12 text-gray-400 peer-checked:text-red-400 mx-auto mb-3"
                                        fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M6 18L18 6M6 6l12 12"></path>
                                    </svg>
                                    <div class="text-xl font-bold text-gray-300 peer-checked:text-red-300">No</div>
                                </div>
                            </label>
                        </div>
                    <?php elseif($question->type === 'multiple_choice'): ?>
                        
                        <div class="space-y-3">
                            <?php $__currentLoopData = json_decode($question->options, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="block cursor-pointer">
                                    <input type="radio" name="answer" value="<?php echo e($value); ?>" class="peer sr-only"
                                        <?php echo e($previousAnswer && $previousAnswer->answer == $value ? 'checked' : ''); ?>

                                        required>
                                    <div
                                        class="bg-white/5 border-2 border-gray-500 rounded-xl p-5 transition-all peer-checked:border-purple-500 peer-checked:bg-purple-500/20 hover:border-purple-400 hover:bg-white/10">
                                        <div class="flex items-center gap-3">
                                            <div
                                                class="w-6 h-6 rounded-full border-2 border-gray-500 peer-checked:border-purple-500 peer-checked:bg-purple-500 flex items-center justify-center">
                                                <svg class="w-4 h-4 text-white hidden peer-checked:block"
                                                    fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd"
                                                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                                        clip-rule="evenodd"></path>
                                                </svg>
                                            </div>
                                            <span
                                                class="text-gray-300 peer-checked:text-white font-medium"><?php echo e($label); ?></span>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <div class="flex gap-4 mt-8">
                        <?php if($questionNumber > 1): ?>
                            <a href="<?php echo e(route('tests.question', ['id' => $test->id, 'question' => $questionNumber - 1])); ?>"
                                class="flex-1 bg-white/10 text-white px-6 py-4 rounded-lg font-semibold hover:bg-white/20 transition-all text-center flex items-center justify-center gap-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 19l-7-7 7-7"></path>
                                </svg>
                                Anterior
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('tests.index')); ?>"
                                class="flex-1 bg-white/10 text-white px-6 py-4 rounded-lg font-semibold hover:bg-white/20 transition-all text-center">
                                Cancelar
                            </a>
                        <?php endif; ?>

                        
                        <?php if($questionNumber < $test->total_questions): ?>
                            <button type="submit"
                                class="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-4 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all flex items-center justify-center gap-2">
                                Siguiente
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7">
                                    </path>
                                </svg>
                            </button>
                        <?php else: ?>
                            <button type="submit"
                                class="flex-1 bg-green-600 text-white px-6 py-4 rounded-lg font-semibold hover:bg-green-700 transition-all flex items-center justify-center gap-2">
                                Finalizar Test
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7"></path>
                                </svg>
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            
            <div class="bg-white/5 backdrop-blur-lg rounded-xl p-4 border border-white/20 text-center">
                <p class="text-gray-400 text-sm">
                    Has respondido <span class="text-purple-400 font-bold"><?php echo e($answeredCount); ?></span> de <span
                        class="text-white font-bold"><?php echo e($test->total_questions); ?></span> preguntas
                </p>
            </div>
        </div>
    </div>

    
    <script>
        <?php if($questionNumber < $test->total_questions): ?>
            // Auto-enviar para preguntas intermedias
            document.querySelectorAll('input[name="answer"]').forEach(input => {
                input.addEventListener('change', function() {
                    setTimeout(() => {
                        document.getElementById('answerForm').submit();
                    }, 300);
                });
            });
        <?php else: ?>
            // Para la última pregunta, solo verificar que haya respuesta
            document.getElementById('answerForm').addEventListener('submit', function(e) {
                const selectedAnswer = document.querySelector('input[name="answer"]:checked');
                if (!selectedAnswer) {
                    e.preventDefault();
                    alert('Por favor selecciona una respuesta antes de finalizar el test.');
                }
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\jose\U Continental\CICLO202520\TALLER_PROYECTOS1\Sistema_IA\Sistema_IA_Vocacional_ML\resources\views/tests/question.blade.php ENDPATH**/ ?>