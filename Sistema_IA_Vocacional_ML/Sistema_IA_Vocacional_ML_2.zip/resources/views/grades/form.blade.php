@extends('layouts.dashboard')

@section('title', 'Cargar Notas Académicas')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
    <div class="max-w-4xl mx-auto">
        <div class="mb-8">
            <h1 class="text-4xl font-bold text-white mb-2">Tus Notas Académicas</h1>
            <p class="text-gray-300">Ingresa tus calificaciones para obtener predicciones más precisas</p>
        </div>

        <div class="bg-white/10 backdrop-blur-lg rounded-xl p-8 border border-white/20">
            <form method="POST" action="{{ route('grades.store') }}">
                @csrf

                <div class="mb-8">
                    <label class="block text-white font-semibold mb-2">Año Académico</label>
                    <input type="number" name="academic_year" min="2020" max="{{ date('Y') }}" value="{{ date('Y') }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-500 focus:outline-none" required>
                </div>

                <div class="grid md:grid-cols-2 gap-6 mb-8">
                    <div>
                        <label class="block text-white font-semibold mb-2">Matemática (0-20)</label>
                        <input type="number" name="nota_matematica" min="0" max="20" value="{{ $grades->nota_matematica ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Comunicación (0-20)</label>
                        <input type="number" name="nota_comunicacion" min="0" max="20" value="{{ $grades->nota_comunicacion ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Ciencias Sociales (0-20)</label>
                        <input type="number" name="nota_ciencias_sociales" min="0" max="20" value="{{ $grades->nota_ciencias_sociales ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Ciencia y Tecnología (0-20)</label>
                        <input type="number" name="nota_ciencia_tecnologia" min="0" max="20" value="{{ $grades->nota_ciencia_tecnologia ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Desarrollo Personal (0-20)</label>
                        <input type="number" name="nota_desarrollo_personal" min="0" max="20" value="{{ $grades->nota_desarrollo_personal ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Ciudadanía Cívica (0-20)</label>
                        <input type="number" name="nota_ciudadania_civica" min="0" max="20" value="{{ $grades->nota_ciudadania_civica ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Educación Física (0-20)</label>
                        <input type="number" name="nota_educacion_fisica" min="0" max="20" value="{{ $grades->nota_educacion_fisica ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Inglés (0-20)</label>
                        <input type="number" name="nota_ingles" min="0" max="20" value="{{ $grades->nota_ingles ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                    <div>
                        <label class="block text-white font-semibold mb-2">Educación y Trabajo (0-20)</label>
                        <input type="number" name="nota_educacion_trabajo" min="0" max="20" value="{{ $grades->nota_educacion_trabajo ?? '' }}" class="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white" required>
                    </div>
                </div>

                <div class="flex gap-4">
                    <a href="{{ route('dashboard') }}" class="flex-1 bg-white/10 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/20 transition-all text-center">
                        Cancelar
                    </a>
                    <button type="submit" class="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all">
                        Guardar Notas
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
