@extends('layouts.dashboard')

@section('title', 'Resultados del Test')

@section('content')
    <div class="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div class="max-w-5xl mx-auto">
            <!-- Updated header with modern design and consistent spacing -->
            <div class="text-center mb-8">
                <div class="mx-auto h-24 w-24 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center mb-4 animate-bounce shadow-lg">
                    <svg class="h-12 w-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
                <h1 class="text-4xl font-bold text-slate-900 mb-2">¡Test Completado!</h1>
                <p class="text-slate-600 text-lg">Aquí están tus resultados personalizados basados en análisis RIASEC</p>
            </div>

            <!-- Profile analysis card with improved styling and readability -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-6">
                <h2 class="text-2xl font-bold text-slate-900 mb-4">Tu Perfil Vocacional</h2>
                <div class="text-slate-700 leading-relaxed prose prose-sm max-w-none">
                    {!! $result->analysis !!}
                </div>
            </div>

            <!-- Category scores with modern progress bars and consistent colors -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-6">
                <h2 class="text-2xl font-bold text-slate-900 mb-6">Tus Áreas de Interés</h2>
                <div class="space-y-4">
                    @foreach ($result->scores as $category => $score)
                        @php
                            $percentage = ($score / 50) * 100;
                            $colors = [
                                'realista' => ['from-indigo-500', 'to-indigo-600', 'bg-indigo-50', 'text-indigo-700'],
                                'investigador' => ['from-blue-500', 'to-blue-600', 'bg-blue-50', 'text-blue-700'],
                                'artistico' => ['from-pink-500', 'to-pink-600', 'bg-pink-50', 'text-pink-700'],
                                'social' => ['from-emerald-500', 'to-emerald-600', 'bg-emerald-50', 'text-emerald-700'],
                                'emprendedor' => ['from-amber-500', 'to-amber-600', 'bg-amber-50', 'text-amber-700'],
                                'convencional' => ['from-slate-500', 'to-slate-600', 'bg-slate-50', 'text-slate-700'],
                            ];
                            $color = $colors[$category] ?? ['from-gray-500', 'to-gray-600', 'bg-gray-50', 'text-gray-700'];
                        @endphp
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center gap-3">
                                    <div class="px-3 py-1 rounded-full {{ $color[2] }} {{ $color[3] }} text-sm font-semibold capitalize">
                                        {{ ucfirst($category) }}
                                    </div>
                                </div>
                                <span class="text-slate-900 font-bold">{{ number_format($percentage, 1) }}%</span>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                                <div class="bg-gradient-to-r {{ $color[0] }} {{ $color[1] }} h-full rounded-full transition-all duration-1000"
                                    style="width: {{ $percentage }}%"></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- Recommended careers with improved card design and consistent layout -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-6">
                <h2 class="text-2xl font-bold text-slate-900 mb-6">Carreras Recomendadas</h2>
                <div class="grid md:grid-cols-3 gap-6">
                    @foreach ($result->recommended_careers as $index => $recommendation)
                        @php
                            $colors = [
                                'realista' => 'indigo',
                                'investigador' => 'blue',
                                'artistico' => 'pink',
                                'social' => 'emerald',
                                'emprendedor' => 'amber',
                                'convencional' => 'slate',
                            ];
                            $color = $colors[$recommendation['category']] ?? 'indigo';
                        @endphp
                        <div class="bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg border border-slate-200 p-6 hover:shadow-md transition-shadow">
                            <div class="flex items-center gap-3 mb-4">
                                <div class="bg-gradient-to-br from-{{ $color }}-500 to-{{ $color }}-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg">
                                    {{ $index + 1 }}
                                </div>
                                <div>
                                    <h3 class="text-slate-900 font-bold">{{ $recommendation['category_name'] }}</h3>
                                    <p class="text-slate-600 text-sm">{{ $recommendation['percentage'] }}% de afinidad</p>
                                </div>
                            </div>
                            <p class="text-slate-700 text-sm mb-4 leading-relaxed">{{ $recommendation['description'] }}</p>
                            <div class="space-y-2">
                                <p class="text-slate-900 font-semibold text-sm">Carreras sugeridas:</p>
                                @foreach (array_slice($recommendation['careers'], 0, 5) as $career)
                                    <div class="flex items-center gap-2 text-slate-700 text-sm">
                                        <svg class="w-4 h-4 text-{{ $color }}-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                                        </svg>
                                        <span>{{ $career }}</span>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- Action buttons with unified styling -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="{{ route('tests.index') }}"
                    class="bg-slate-100 hover:bg-slate-200 text-slate-900 px-6 py-3 rounded-lg font-semibold transition-colors text-center">
                    Volver a Tests
                </a>

                <a href="{{ route('dashboard.careers') }}"
                    class="bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all text-center">
                    Explorar Carreras
                </a>

                <a href="{{ route('tests.restart', $result->vocational_test_id) }}"
                    class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors text-center">
                    Reiniciar Test
                </a>

                <button onclick="window.print()"
                    class="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors">
                    Descargar
                </button>
            </div>

        </div>
    </div>
@endsection
