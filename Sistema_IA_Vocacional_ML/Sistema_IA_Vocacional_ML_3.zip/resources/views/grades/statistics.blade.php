@extends('layouts.dashboard')

@section('title', 'Estadísticas de Notas')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
    <div class="max-w-7xl mx-auto">
        <div class="mb-8">
            <h1 class="text-4xl font-bold text-white mb-2">Estadísticas de Notas Académicas</h1>
            <p class="text-gray-300">Dashboard de orientadores - Año {{ date('Y') }}</p>
        </div>

        @if($statistics)
            @php $stats = $statistics[0]; @endphp
            <div class="grid md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
                <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                    <div class="text-gray-400 text-sm font-semibold mb-2">Total Estudiantes</div>
                    <div class="text-3xl font-bold text-white">{{ $stats->total_students }}</div>
                </div>
                <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                    <div class="text-gray-400 text-sm font-semibold mb-2">Promedio Matemática</div>
                    <div class="text-3xl font-bold text-blue-400">{{ $stats->avg_matematica }}</div>
                </div>
                <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                    <div class="text-gray-400 text-sm font-semibold mb-2">Promedio Comunicación</div>
                    <div class="text-3xl font-bold text-green-400">{{ $stats->avg_comunicacion }}</div>
                </div>
                <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                    <div class="text-gray-400 text-sm font-semibold mb-2">Promedio Tecnología</div>
                    <div class="text-3xl font-bold text-orange-400">{{ $stats->avg_tecnologia }}</div>
                </div>
                <div class="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                    <div class="text-gray-400 text-sm font-semibold mb-2">Promedio General</div>
                    @php
                        $generalAverage = (
                            $stats->avg_matematica +
                            $stats->avg_comunicacion +
                            $stats->avg_sociales +
                            $stats->avg_tecnologia +
                            $stats->avg_personal +
                            $stats->avg_civica +
                            $stats->avg_fisica +
                            $stats->avg_ingles +
                            $stats->avg_trabajo
                        ) / 9;
                    @endphp
                    <div class="text-3xl font-bold text-purple-400">{{ round($generalAverage, 2) }}</div>
                </div>
            </div>

            <div class="bg-white/10 backdrop-blur-lg rounded-xl p-8 border border-white/20 mb-8">
                <h2 class="text-2xl font-bold text-white mb-6">Promedios por Materia</h2>
                <div class="space-y-4">
                    @php
                        $subjects = [
                            'Matemática' => $stats->avg_matematica,
                            'Comunicación' => $stats->avg_comunicacion,
                            'Sociales' => $stats->avg_sociales,
                            'Tecnología' => $stats->avg_tecnologia,
                            'Personal' => $stats->avg_personal,
                            'Cívica' => $stats->avg_civica,
                            'Física' => $stats->avg_fisica,
                            'Inglés' => $stats->avg_ingles,
                            'Trabajo' => $stats->avg_trabajo,
                        ];
                    @endphp
                    @foreach($subjects as $subject => $average)
                        @php $percentage = ($average / 20) * 100; @endphp
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-white font-semibold">{{ $subject }}</span>
                                <span class="text-gray-300">{{ $average }}/20</span>
                            </div>
                            <div class="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                                <div class="bg-gradient-to-r from-purple-600 to-pink-600 h-full rounded-full" style="width: {{ $percentage }}%"></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="bg-white/10 backdrop-blur-lg rounded-xl p-8 border border-white/20">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-bold text-white">Top 10 Estudiantes</h2>
                    <a href="{{ route('grades.export') }}" class="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all">
                        Descargar Reporte CSV
                    </a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="text-left text-gray-300 border-b border-white/10">
                                <th class="pb-4 font-semibold">Posición</th>
                                <th class="pb-4 font-semibold">Nombre</th>
                                <th class="pb-4 font-semibold">Grado</th>
                                <th class="pb-4 font-semibold">Promedio</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($topStudents as $index => $student)
                                <tr class="border-b border-white/5 hover:bg-white/5 transition-all">
                                    <td class="py-4">
                                        <span class="bg-gradient-to-br from-purple-600 to-pink-600 text-white px-3 py-1 rounded-full font-semibold">
                                            #{{ $index + 1 }}
                                        </span>
                                    </td>
                                    <td class="py-4 text-white">{{ $student->name }}</td>
                                    <td class="py-4 text-gray-300">{{ $student->grade }}</td>
                                    <td class="py-4 text-gray-300 font-bold">{{ $student->average_grade }}/20</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @endif

        <div class="mt-8 flex gap-4">
            <a href="{{ route('dashboard') }}" class="flex-1 bg-white/10 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/20 transition-all text-center">
                Volver al Dashboard
            </a>
        </div>
    </div>
</div>
@endsection
