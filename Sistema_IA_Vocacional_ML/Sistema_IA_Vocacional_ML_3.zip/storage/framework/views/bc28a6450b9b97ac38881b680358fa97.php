<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" <?php echo e($attributes); ?>>
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
</svg>
<?php /**PATH D:\jose\U Continental\CICLO202520\TALLER_PROYECTOS1\Sistema_IA\Sistema_IA_Vocacional_ML\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/check.blade.php ENDPATH**/ ?>