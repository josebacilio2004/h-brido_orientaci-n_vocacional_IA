#!/usr/bin/env python3
"""
Random Forest Career Prediction Model
Predice carreras recomendadas basadas en características del estudiante
"""

import json
import sys
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import pickle
import os

class CareerPredictionModel:
    def __init__(self, model_path='storage/app/ml-models/career_model.pkl'):
        self.model_path = model_path
        self.model = None
        self.feature_names = [
            'age', 'gpa', 'interest_avg', 'skill_avg', 'personality_avg'
        ]
        self.performance_metrics = {
            'accuracy': 0.0,
            'precision': 0.0,
            'recall': 0.0,
            'f1_score': 0.0
        }

    def extract_numeric_features(self, features):
        """Extraer características numéricas de los datos del estudiante"""
        try:
            numeric_features = [
                float(features.get('age', 0)) / 100,  # Normalizar edad
                float(features.get('gpa', 0)) / 4.0,   # Normalizar GPA
                np.mean(features.get('interest_scores', [0])),
                np.mean(features.get('skill_scores', [0])),
                np.mean(features.get('personality_traits', [0])),
            ]
            return np.array(numeric_features).reshape(1, -1)
        except Exception as e:
            print(f"Error extracting features: {e}", file=sys.stderr)
            return None

    def predict(self, features):
        """Generar predicción de carreras"""
        try:
            if not self.model_exists():
                return self.get_default_prediction()

            with open(self.model_path, 'rb') as f:
                self.model = pickle.load(f)

            numeric_features = self.extract_numeric_features(features)
            if numeric_features is None:
                return self.get_default_prediction()

            probabilities = self.model.predict_proba(numeric_features)[0]
            confidence = float(np.max(probabilities))

            return {
                'predictions': probabilities.tolist(),
                'confidence': confidence,
                'success': True
            }
        except Exception as e:
            print(f"Prediction error: {e}", file=sys.stderr)
            return self.get_default_prediction()

    def model_exists(self):
        """Verificar si el modelo entrenado existe"""
        return os.path.exists(self.model_path)

    def get_default_prediction(self):
        """Retornar predicción por defecto si el modelo no existe"""
        return {
            'predictions': [0.2] * 10,  # 10 carreras iguales
            'confidence': 0.5,
            'success': True,
            'warning': 'Using default prediction - model not trained yet'
        }

    def train(self, training_data):
        """Entrenar el modelo con datos históricos"""
        try:
            X = []
            y = []

            for record in training_data:
                features = self.extract_numeric_features(record['features'])
                if features is not None:
                    X.append(features[0])
                    y.append(record['label'])

            if len(X) == 0:
                raise Exception("No training data available")

            X = np.array(X)
            y = np.array(y)

            # Entrenar Random Forest
            self.model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                min_samples_split=5,
                random_state=42
            )
            self.model.fit(X, y)

            # Guardar modelo
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            with open(self.model_path, 'wb') as f:
                pickle.dump(self.model, f)

            # Calcular métricas
            accuracy = self.model.score(X, y)

            return {
                'success': True,
                'accuracy': float(accuracy),
                'precision': float(accuracy),  # Simplified
                'recall': float(accuracy),      # Simplified
                'f1_score': float(accuracy),    # Simplified
                'samples_trained': len(X),
                'confusion_matrix': []
            }
        except Exception as e:
            print(f"Training error: {e}", file=sys.stderr)
            return {
                'success': False,
                'error': str(e)
            }

def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'Missing input data'}), file=sys.stderr)
        sys.exit(1)

    try:
        input_data = json.loads(sys.argv[1])
    except json.JSONDecodeError:
        print(json.dumps({'error': 'Invalid JSON input'}), file=sys.stderr)
        sys.exit(1)

    model = CareerPredictionModel()

    if '--train' in sys.argv:
        result = model.train(input_data)
    else:
        result = model.predict(input_data)

    print(json.dumps(result))

if __name__ == '__main__':
    main()
